create
    definer = root@localhost procedure SP_SEARCH(IN p_name char(20))
BEGIN
IF p_name is null or p_name='' THEN
SELECT * FROM t_user; 
ELSE
SELECT * FROM t_user WHERE USER_NAME LIKE p_name; 
END IF; 
END;

