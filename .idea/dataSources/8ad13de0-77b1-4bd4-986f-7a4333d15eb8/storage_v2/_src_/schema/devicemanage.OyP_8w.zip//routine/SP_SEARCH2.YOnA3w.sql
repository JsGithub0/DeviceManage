create
    definer = root@localhost procedure SP_SEARCH2(IN p_name char(20), OUT p_int int)
BEGIN
IF p_name is null or p_name='' THEN
SELECT * FROM t_user; 
ELSE
SELECT * FROM t_user WHERE USER_NAME LIKE p_name; 
END IF; 
SELECT FOUND_ROWS() INTO p_int; 
END;

