create
    definer = root@localhost procedure getMoneyAmount(IN soId int)
BEGIN
SELECT ShopingOrderID,SUM(DevicePrice*BuyNum) MoneyAmount FROM shopingorderitem INNER JOIN device ON device.DeviceID=shopingorderitem.DeviceID WHERE ShopingOrderID=soId;
END;

