create
    definer = root@localhost procedure in_param(IN p_in int)
BEGIN
	SELECT p_in;
  SET p_in=2;
  SELECT p_in;
END;

