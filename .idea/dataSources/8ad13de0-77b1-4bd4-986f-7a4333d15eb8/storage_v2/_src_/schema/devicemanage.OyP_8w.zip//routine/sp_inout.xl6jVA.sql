create
    definer = root@localhost procedure sp_inout(INOUT p_num int)
BEGIN
SET p_num=p_num*10; 
END;

